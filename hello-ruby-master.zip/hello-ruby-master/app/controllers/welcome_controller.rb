class WelcomeController < ApplicationController

  # GET /welcome
  def index

  end
def index2

  end
end
